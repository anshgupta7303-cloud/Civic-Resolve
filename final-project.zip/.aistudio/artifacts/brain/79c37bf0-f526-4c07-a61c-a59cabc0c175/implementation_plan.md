# CivicResolve - Smart Municipal Grievance Redressal Portal

Deploy and restore the complete municipal grievance management portal from the provided project archive, featuring automated department routing, SLA countdowns, officer ground inspection verification, and executive reporting.

> [!IMPORTANT]
> **User Confirmed Decisions:**
> - **Deployment Mode**: Extract and restore the complete CivicResolve municipal platform directly from the provided zip archive (`public/assets/aistudio/fileopener__5__63f2f1e8.zip`).
> - **Core Feature Emphasis**:
>   1. Standard grievance submission with photographic evidence and duplicate detection.
>   2. Live SLA countdowns, warnings, and automated supervisory escalation queues.
>   3. Field ward officer ground inspections with before & after photographic verification.
>   4. Exportable CSV and printable executive PDF summary reports in the Admin Command Center.

---

## 1. Overview & Core Concept

**CivicResolve** is a full-stack digital municipal grievance redressal and citizen service governance platform. It bridges citizens, ward engineers, and municipal leadership to eliminate manual bureaucracy and enforce public accountability.

- **Target Personas**:
  - **Resident Citizens**: Lodge issues (potholes, water pipe bursts, streetlight failures, garbage overflows) with photos, track live progress, and upvote existing community issues.
  - **Ward Field Officers**: Receive auto-routed work orders, inspect damage on-site, and upload stamped proof photos to close tickets.
  - **Municipal Administrators & Commissioners**: Monitor live SLA compliance across all wards, intervene on breached tickets, analyze chronic infrastructure hotspots, and export executive reports.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Resident Submission & Duplicate Detection**:
   - Citizen enters a grievance title and description.
   - The client performs debounced duplicate checks against active ward tickets to prevent redundant work orders.
   - Photo evidence can be dragged and dropped or selected from realistic presets.
2. **Real-Time SLA & Audit Timeline**:
   - Tracking page displays a visual 3-stage stepper (Registered & Triaged → Field Crew Dispatched → Verified & Resolved).
   - Color-coded SLA indicators display exact countdown windows or breach overdue metrics.
   - Chronological audit log records every status update with officer identity.
3. **Field Officer Inspection Workflow**:
   - Officers change ticket status to `IN_PROGRESS` or `RESOLVED`, adding official field remarks and before-and-after photo evidence.
4. **Admin Command Center & Data Export**:
   - Real-time KPI telemetry (Total Grievances, Resolution Rate %, SLA Escalations, Emergency Triage).
   - Action Queue prioritizing breached or critical complaints.
   - Ward Performance Index and Department distribution charts.
   - **Export Feature**: Download CSV roster of all complaints and generate clean printable PDF executive summaries.

### Visual Identity & Styling
- **Aesthetic**: Utilitarian, trustworthy, civic-grade interface adhering strictly to anti-slop guidelines.
- **Palette**: Slate neutral canvas (`#0F172A` / `#F8FAFC`), emerald primary (`#059669`) for positive civic resolution, amber (`#D97706`) for warnings, and crimson (`#DC2626`) for critical SLA breaches.
- **Typography**: Clean display typography (`Plus Jakarta Sans`) paired with monospace tabular figures (`font-mono tabular-nums`) for ticket IDs, countdown timers, and percentages.
- **Zero-Pill Discipline**: Metadata displayed with clean separators (`·` or `/`) instead of gratuitous capsule badges.

---

## 3. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────┐
│                   React 19 Frontend                    │
│  ┌──────────────┐ ┌───────────────┐ ┌───────────────┐  │
│  │ Citizen Flow │ │ Officer Flow  │ │  Admin Center │  │
│  │ (Submit/Map) │ │ (Field Proof) │ │ (KPIs/Export) │  │
│  └──────┬───────┘ └───────┬───────┘ └───────┬───────┘  │
│         │                 │                 │          │
│         ▼                 ▼                 ▼          │
│                 REST Client (/api/*)                   │
└───────────────────────────┬────────────────────────────┘
                            │
┌───────────────────────────▼────────────────────────────┐
│               Express Full-Stack Server                │
│                                                        │
│  ┌─────────────────┐ ┌──────────────────────────────┐  │
│  │ Auth & JWT      │ │ Complaint Management         │  │
│  │ Middleware      │ │ & Audit Trails               │  │
│  └────────┬────────┘ └──────────────┬───────────────┘  │
│           │                         │                  │
│  ┌────────▼─────────────────────────▼───────────────┐  │
│  │ Intelligent Business Services                    │  │
│  │  - SLA Engine (Matrix calculation & alerts)      │  │
│  │  - Duplicate Engine (Jaccard similarity)         │  │
│  │  - Priority Engine (Gemini 3.8 Flash + rules)    │  │
│  │  - Insights Engine (Hotspot & cluster detection) │  │
│  │  - Report Engine (CSV / Printable Summary)       │  │
│  └────────────────────────┬─────────────────────────┘  │
│                           │                            │
│  ┌────────────────────────▼─────────────────────────┐  │
│  │ In-Memory Municipal Datastore & Mock Seeding     │  │
│  └──────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────┘
```

### Key Modules & Files
- **Server Entry (`server.ts`)**: Express app serving Vite in development, hosting `/api/auth`, `/api/complaints`, `/api/admin`, and `/api/notifications`.
- **Database & State (`server/db.ts`)**: Structured state containing complaints, departmental SLA matrix, and demo accounts (Citizen, Officer, Admin).
- **Export Utility**:
  - Client-side CSV generator converting filtered complaint collections into structured `.csv` downloads.
  - Formatted print stylesheet enabling one-click browser PDF export of executive metrics.
- **AI Priority & Triage (`server/services/priorityEngine.ts`)**: Leverages `@google/genai` with `gemini-3.8-flash` (with rules fallback) to classify safety hazards and calculate response SLA windows.

---

## 4. Execution Steps (Upon Approval)

1. **Extract Archive**: Unpack all files from `public/assets/aistudio/fileopener__5__63f2f1e8.zip` into the applet root directory.
2. **Install Dependencies**: Install required packages (`bcrypt`, `jsonwebtoken`, `@google/genai`, etc.) using `install_applet_dependencies` or `install_applet_package`.
3. **Implement Export Capabilities**: Add CSV export and printable executive report views in `src/pages/AdminDashboard.tsx`.
4. **Update App Metadata**: Ensure `metadata.json` and `index.html` properly reflect "CivicResolve".
5. **Verify Build**: Test server and client compilation using `compile_applet`.
